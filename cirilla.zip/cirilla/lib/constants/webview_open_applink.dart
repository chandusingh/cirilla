// Define white list open app link

const whiteListOpenAppLink = [
  "mailto:",
  "tel:",
  "sms:",
  "whatsapp:",
  "fb-messenger:",
  "tg:",
  "viber:",
  "line:",
  "skype:",
  "zoommtg:",
  "zalo:",
  "intent:",
];