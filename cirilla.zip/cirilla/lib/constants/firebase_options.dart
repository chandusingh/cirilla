const String apiKey = "AIzaSyCxS3PtP7putzZFFCSxpy2gmsC4-jTmSy8";
const String appId = "1:295269595518:web:9e19ff9142d25651095b2f";
const String messagingSenderId = "295269595518";
const String projectId = "cirilla-rnlab";
