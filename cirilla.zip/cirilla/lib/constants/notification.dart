import 'dart:ui';

const String notificationIcon = 'ic_notification';

const Color notificationColor = Color(0xff0087FF);