import 'package:cirilla/models/cart/cart.dart';
import 'package:cirilla/utils/convert_data.dart';
import 'package:flutter/material.dart';

import '../../../mixins/utility_mixin.dart';
import '../../../types/types.dart';
import '../../../utils/app_localization.dart';
import '../../../utils/currency_format.dart';

import 'package:html_unescape/html_unescape_small.dart';

import 'cart_coupon_list.dart';

class CartTotal extends StatelessWidget {
  final CartData cartData;
  const CartTotal({Key? key, required this.cartData}) : super(key: key);

  String _total(String? value,String? value2) {
    double total = ConvertData.stringToDouble(value, 0) + ConvertData.stringToDouble(value2, 0);
    return total.toString();
  }

  @override
  Widget build(BuildContext context) {
    String? subTotal = get(cartData.totals, ['total_items'], '0');
    String? subTotalTax = get(cartData.totals, ['total_items_tax'], '0');

    String? subTax = get(cartData.totals, ['total_tax'], '0');

    String? totalPrice = get(cartData.totals, ['total_price'], '0');

    int? unit = get(cartData.totals, ['currency_minor_unit'], 0);

    HtmlUnescape unescape = HtmlUnescape();

    String? currencyCode = get(cartData.totals, ['currency_code'], null);
    TranslateType translate = AppLocalizations.of(context)!.translate;
    ThemeData theme = Theme.of(context);
    TextTheme textTheme = theme.textTheme;
    return Column(
      children: [
        buildCartTotal(
          title: translate('cart_sub_total'),
          price: convertCurrency(context, unit: unit, currency: currencyCode, price: _total(subTotal, subTotalTax))!,
          style: textTheme.titleSmall,
        ),
        CartCouponList(cartData: cartData),
        const SizedBox(height: 4),
        ...List.generate(
          cartData.shippingRate!.length,
          (index) {
            ShippingRate shippingRate = cartData.shippingRate!.elementAt(index);

            List data = shippingRate.shipItem!;
            return Column(
              children: List.generate(data.length, (index) {
                ShipItem dataShipInfo = data.elementAt(index);

                String name = get(dataShipInfo.name, [], '');

                String? price = get(dataShipInfo.price, [], '0');
                String? taxes = get(dataShipInfo.taxes, [], '0');

                bool selected = get(dataShipInfo.selected, [], '');

                String? currencyCode = get(dataShipInfo.currencyCode, [], '');

                return selected
                    ? buildCartTotal(
                        title: translate(name),
                        price: convertCurrency(context, unit: unit, currency: currencyCode, price: _total(price, taxes))!,
                        style: textTheme.bodyMedium,
                      )
                    : Container();
              }),
            );
          },
        ),
        const SizedBox(height: 31),
        if(subTax != '0')
          buildCartTotal(
              title: translate('cart_tax'),
              price: convertCurrency(context, unit: unit, currency: currencyCode, price: subTax)!,
              style: textTheme.titleSmall),
        if(cartData.fees?.isNotEmpty == true)...[
          const SizedBox(height: 4),
          ...List.generate(
            cartData.fees!.length,
            (index) {
              CartFees cartFees = cartData.fees!.elementAt(index);
              String? name = cartFees.name;
              Map<String, dynamic>? data = cartFees.totals;
              String? totalFees = get(data, ['total'], '0');
              return buildCartTotal(
                  title: unescape.convert(name!),
                  price: convertCurrency(context, unit: unit, currency: currencyCode, price: totalFees)!,
                  style: textTheme.titleSmall);
            },
          ),
        ],
        const SizedBox(height: 4),
        buildCartTotal(
          title: translate('cart_total'),
          price: convertCurrency(context, unit: unit, currency: currencyCode, price: totalPrice)!,
          style: textTheme.titleMedium,
        ),
      ],
    );
  }
}

Widget buildCartTotal({
  BuildContext? context,
  required String title,
  required String price,
  TextStyle? style,
  Widget? icon,
}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Expanded(
        child: Row(
          children: [
            Flexible(child: Text(title, style: style)),
            if (icon != null) ...[
              const SizedBox(width: 8),
              icon,
            ],
          ],
        ),
      ),
      const SizedBox(width: 12),
      Text(price, style: style),
    ],
  );
}
