const typeViewStyle1 = "style1";
const typeViewStyle2 = "style2";

const typeView = typeViewStyle1;