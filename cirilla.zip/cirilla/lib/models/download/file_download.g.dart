// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'file_download.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FileDownload _$FileDownloadFromJson(Map<String, dynamic> json) => FileDownload(
      name: json['name'] as String?,
      file: json['file'] as String?,
    );

Map<String, dynamic> _$FileDownloadToJson(FileDownload instance) => <String, dynamic>{
      'name': instance.name,
      'file': instance.file,
    };
