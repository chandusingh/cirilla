// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'country_address.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CountryAddressData _$CountryAddressDataFromJson(Map<String, dynamic> json) =>
    CountryAddressData(
      name: json['name'] as String?,
      code: json['code'] as String?,
    );

Map<String, dynamic> _$CountryAddressDataToJson(CountryAddressData instance) =>
    <String, dynamic>{
      'name': instance.name,
      'code': instance.code,
    };
