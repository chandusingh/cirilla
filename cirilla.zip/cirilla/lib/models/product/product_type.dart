String productTypeSimple = 'simple';
String productTypeVariable = 'variable';
String productTypeGrouped = 'grouped';
String productTypeExternal = 'external';
String productTypeAppointment = 'appointment';
String productTypeBooking = 'booking';
