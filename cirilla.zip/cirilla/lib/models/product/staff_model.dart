class StaffModel {
  final String? id;
  final String? name;
  final double? price;
  StaffModel({this.id, this.name, this.price});
}
