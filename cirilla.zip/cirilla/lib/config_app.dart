/// The internetNotificationType has two values is 'default' and 'banner'.
/// If value is 'default', the message will be displayed as a dialog.
/// If value is 'banner', the message will be displayed as a mini banner at top of screen.
const String internetNotificationType = 'default';

